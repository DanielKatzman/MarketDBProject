package shon_daniel;

class Option99 implements Command{

    private MarketFacade marketFacade;

    public Option99(MarketFacade marketFacade) {
        this.marketFacade = marketFacade;
    }

    @Override
    public void execute() {
        marketFacade.option99();
    }
}


class Option100 implements Command{
    private MarketFacade marketFacade;

    public Option100(MarketFacade marketFacade){
        this.marketFacade = marketFacade;
    }

    @Override
    public void execute() {
        marketFacade.option100();
    }
}


class Option101 implements Command{
    private MarketFacade marketFacade;

    public Option101(MarketFacade marketFacade){
        this.marketFacade = marketFacade;
    }

    @Override
    public void execute() {
        marketFacade.option101();
    }
}


class Option102 implements Command{
    private MarketFacade marketFacade;

    public Option102(MarketFacade marketFacade){
        this.marketFacade = marketFacade;
    }

    @Override
    public void execute() {
        marketFacade.option102();
    }
}


class Option103 implements Command{
    private MarketFacade marketFacade;

    public Option103(MarketFacade marketFacade){
        this.marketFacade = marketFacade;
    }

    @Override
    public void execute() {
        marketFacade.option103();
    }
}


class Option104 implements Command{
    private MarketFacade marketFacade;

    public Option104(MarketFacade marketFacade){
        this.marketFacade = marketFacade;
    }

    @Override
    public void execute() {
        marketFacade.option104();
    }
}


class Option105 implements Command{
    private MarketFacade marketFacade;

    public Option105(MarketFacade marketFacade){
        this.marketFacade = marketFacade;
    }

    @Override
    public void execute() {
        marketFacade.option105();
    }
}


