package shon_daniel;

public interface TargetAdapter {
    boolean myHasNext();
    String myNext();
    boolean myHasPrevious();
    String myPrevious();
}
