package shon_daniel;

public enum Category {
    KIDS,ELECTRICITY,OFFICE,CLOTHING;

}

