package shon_daniel;

public enum UserEnum {
    BUYER, SELLER
}
