package shon_daniel;

public interface Command {
    void execute();
}
