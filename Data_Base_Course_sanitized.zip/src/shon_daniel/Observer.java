package shon_daniel;

public interface Observer {
    void update(MarketManager subject);
}
